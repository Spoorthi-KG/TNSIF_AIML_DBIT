import argparse
import joblib
import numpy as np
from src.utils import load_data

def main(model_path: str, n_samples: int = 5):
    model = joblib.load(model_path)
    X_train, X_test, y_train, y_test = load_data()
    X_sample = X_test[:n_samples]
    y_true = y_test[:n_samples]

    y_pred = model.predict(X_sample)
    for i, (pred, true) in enumerate(zip(y_pred, y_true)):
        print(f"Sample {i}: predicted={pred} (0=malignant,1=benign), true={true}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str, default='models/model.joblib')
    args = parser.parse_args()
    main(args.model)
