import argparse
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import classification_report, confusion_matrix
from src.utils import load_data

def main(output_path: str):
    X_train, X_test, y_train, y_test = load_data()

    pipe = Pipeline([
        ("scaler", StandardScaler()),
        ("clf", RandomForestClassifier(random_state=42))
    ])

    param_grid = {
        'clf__n_estimators': [50, 100],
        'clf__max_depth': [None, 8, 16],
        'clf__min_samples_split': [2, 5]
    }

    gs = GridSearchCV(pipe, param_grid, cv=5, scoring='f1', n_jobs=-1)
    gs.fit(X_train, y_train)

    print("Best params:", gs.best_params_)
    y_pred = gs.predict(X_test)
    print("Classification report:", classification_report(y_test, y_pred))
    print("Confusion matrix:", confusion_matrix(y_test, y_pred))

    joblib.dump(gs.best_estimator_, output_path)
    print(f"Saved best model to {output_path}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=str, default='models/model.joblib')
    args = parser.parse_args()
    main(args.output)
